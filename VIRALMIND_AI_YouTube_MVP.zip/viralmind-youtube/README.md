# VIRALMIND AI — YouTube Automation MVP

Mobile-first web app/PWA. This is a deployable starter MVP, not a hosted service yet.

## What works when configured
- Optional YouTube URL lookup for public title/channel/thumbnail metadata (does NOT fetch video or transcript).
- Original script + title/description/scene prompts using OpenAI API.
- Urdu/Hindi/English voiceover using ElevenLabs.
- 9:16 MP4 slideshow rendering from user-provided/licensed images plus generated voiceover, using FFmpeg.
- Mobile browser UI and installable PWA shell.

## Not included yet
- Automatic transcript extraction from arbitrary YouTube links.
- AI image/video clip generation from prompts.
- Full timeline editor, background music/subtitle burn-in.
- YouTube OAuth upload/publishing.
These require additional providers, permissions, and implementation. Do not use content without rights/permission.

## Run
Requires Node.js 20+ and network access.

```bash
cp .env.example .env
# set OPENAI_API_KEY and ELEVENLABS_API_KEY in .env
npm install
npm start
```
Open `http://localhost:3000`.

## Deploy
Deploy the Node app to a host that supports persistent file storage and FFmpeg execution. Set the environment variables from `.env.example` in the host dashboard. A serverless host with short execution limits may not support video rendering reliably; use a persistent Node service/container for rendering. Put API keys only in server environment variables, never in browser code.

## API keys
- OpenAI: https://platform.openai.com/api-keys
- ElevenLabs: https://elevenlabs.io/
