import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import OpenAI from 'openai';
import multer from 'multer';
import ffmpegPath from 'ffmpeg-static';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const execFileAsync = promisify(execFile);
const upload = multer({ dest: path.join(__dirname, 'uploads'), limits: { fileSize: 150 * 1024 * 1024 } });
app.use(cors());
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/outputs', express.static(path.join(__dirname, 'outputs')));
await fs.mkdir(path.join(__dirname, 'uploads'), { recursive: true });
await fs.mkdir(path.join(__dirname, 'outputs'), { recursive: true });

app.get('/api/status', (_req, res) => res.json({ ok: true, openai: Boolean(process.env.OPENAI_API_KEY), elevenlabs: Boolean(process.env.ELEVENLABS_API_KEY) }));

app.post('/api/youtube-info', async (req, res) => {
  try {
    const url = String(req.body.url || '').trim();
    if (!/^https?:\/\/(www\.)?(youtube\.com|youtu\.be)\//i.test(url)) return res.status(400).json({ error: 'Valid YouTube URL enter karein.' });
    const response = await fetch(`https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`);
    if (!response.ok) throw new Error('YouTube video details could not be retrieved.');
    const info = await response.json();
    res.json({ title: info.title, author: info.author_name, thumbnail: info.thumbnail_url, note: 'Yeh sirf public title/metadata hai; transcript automatically fetch nahi hota. Apna transcript ya notes neeche paste karein.' });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.post('/api/script', async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) return res.status(400).json({ error: 'Server par OPENAI_API_KEY set karein.' });
    const { topic, sourceNotes = '', instructions = '', language = 'English', format = 'Long Video', duration = '5 minutes' } = req.body;
    if (!topic?.trim()) return res.status(400).json({ error: 'Video topic zaroor likhein.' });
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const prompt = `Create a fully original YouTube video package. Use the source only as inspiration and do not copy its wording or structure.\nTopic: ${topic}\nReference notes/transcript (optional): ${sourceNotes}\nFormat: ${format}; target duration: ${duration}; language: ${language}.\nExtra instructions: ${instructions}\nReturn: 1) catchy title, 2) description, 3) complete narration script, 4) 8-20 scene plan with visual prompts, 5) thumbnail prompt. Make the narration natural and original.`;
    const result = await client.chat.completions.create({ model: process.env.OPENAI_MODEL || 'gpt-4o-mini', messages: [{ role: 'system', content: 'You are an expert original YouTube producer. Never claim to have watched a video unless its transcript or content was supplied.' }, { role: 'user', content: prompt }] });
    res.json({ package: result.choices?.[0]?.message?.content || '' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/voice', async (req, res) => {
  try {
    if (!process.env.ELEVENLABS_API_KEY) return res.status(400).json({ error: 'Server par ELEVENLABS_API_KEY set karein.' });
    const text = String(req.body.text || '').trim();
    if (!text) return res.status(400).json({ error: 'Voiceover text missing.' });
    const voice = process.env.ELEVENLABS_VOICE_ID || '21m00Tcm4TlvDq8ikWAM';
    const r = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voice}`, { method: 'POST', headers: { 'xi-api-key': process.env.ELEVENLABS_API_KEY, 'Content-Type': 'application/json', 'Accept': 'audio/mpeg' }, body: JSON.stringify({ text, model_id: 'eleven_multilingual_v2', voice_settings: { stability: 0.45, similarity_boost: 0.75 } }) });
    if (!r.ok) throw new Error(`ElevenLabs error: ${await r.text()}`);
    const file = `voice-${Date.now()}.mp3`;
    await fs.writeFile(path.join(__dirname, 'outputs', file), Buffer.from(await r.arrayBuffer()));
    res.json({ url: `/outputs/${file}` });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/render', upload.array('images', 20), async (req, res) => {
  const uploaded = req.files || [];
  try {
    if (!uploaded.length) return res.status(400).json({ error: 'Kam az kam 1 image upload karein. Scene visuals aapke apne ya licensed hone chahiye.' });
    const voiceName = String(req.body.voice || '');
    const voicePath = path.join(__dirname, 'outputs', path.basename(voiceName));
    if (!voiceName || !voiceName.endsWith('.mp3')) return res.status(400).json({ error: 'Pehle AI voiceover generate karein.' });
    await fs.access(voicePath);
    const outName = `video-${Date.now()}.mp4`;
    const outPath = path.join(__dirname, 'outputs', outName);
    const listPath = path.join(__dirname, 'uploads', `list-${Date.now()}.txt`);
    const duration = Math.max(3, Math.min(12, 60 / uploaded.length));
    const lines = [];
    for (const f of uploaded) {
      const ext = path.extname(f.originalname).toLowerCase() || '.jpg';
      const safe = `${f.filename}${ext}`;
      const target = path.join(__dirname, 'uploads', safe);
      await fs.rename(f.path, target);
      lines.push(`file '${target.replace(/'/g, "'\\''")}'\nduration ${duration}`);
    }
    lines.push(`file '${path.join(__dirname, 'uploads', `${path.basename(uploaded.at(-1).filename)}${path.extname(uploaded.at(-1).originalname).toLowerCase() || '.jpg'}`).replace(/'/g, "'\\''")}'`);
    await fs.writeFile(listPath, lines.join('\n'));
    await execFileAsync(ffmpegPath, ['-y', '-f', 'concat', '-safe', '0', '-i', listPath, '-i', voicePath, '-vf', "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2,format=yuv420p", '-c:v', 'libx264', '-preset', 'veryfast', '-r', '30', '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', outPath]);
    res.json({ url: `/outputs/${outName}` });
  } catch (e) { res.status(500).json({ error: e.message }); }
  finally { for (const f of uploaded) { try { await fs.unlink(f.path); } catch {} } }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`VIRALMIND AI running on http://localhost:${port}`));
